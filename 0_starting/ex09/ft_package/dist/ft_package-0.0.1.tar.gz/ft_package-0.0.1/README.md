# ft_packege
is a test package created under the 42 schools curriculum